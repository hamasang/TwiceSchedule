package hama.ialpha.kr.twiceschedule2;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by sang on 2016-12-31.
 */

public class Notification_Activity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start_activity);
    }
}
