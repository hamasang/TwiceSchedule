package hama.ialpha.kr.twiceschedule2.firebase;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.google.firebase.messaging.RemoteMessage;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Date;

import hama.ialpha.kr.twiceschedule2.MainActivity;
import hama.ialpha.kr.twiceschedule2.R;


public class FirebaseMessagingService extends com.google.firebase.messaging.FirebaseMessagingService {
    private static final String TAG = "FirebaseMsgService";
    String msg = "";
    boolean contains;
    String http="http://";
    boolean httpsb;
    String https="https://";
    String url = "";
    int url_length = 0;
    int s = (int) System.currentTimeMillis() ;
    // [START receive_message]
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        try {
            //추가한것
            sendNotification(remoteMessage.getData().get("messages"), s);
        }catch (Exception e){
            Log.e("ERROR","Received Error");
        }
    }

    private void sendNotification(String messageBody, int m_cnt) {

        Intent intent;
        // 현재시간을 msec 으로 구한다.
        long now = System.currentTimeMillis();
        // 현재시간을 date 변수에 저장한다.
        Date date = new Date(now);
        // 시간을 나타냇 포맷을 정한다 ( yyyy/MM/dd 같은 형태로 변형 가능 )
        SimpleDateFormat sdfNow = new SimpleDateFormat("yyyy/MM/dd HH:mm");
        SimpleDateFormat time = new SimpleDateFormat("HH");
        // nowDate 변수에 값을 저장한다.
        String formatDate = sdfNow.format(date);
        String formatTime = time.format(date);
        //messageBody = URLDecoder.decode(messageBody,"UTF-8");
        msg = messageBody;
        contains = msg.contains(http);
        httpsb = msg.contains(https);
        if(contains || httpsb){
            if(httpsb){
                url_length = msg.indexOf(https);
            }else if(contains){
                url_length = msg.indexOf(http);
            }
            url = msg.substring(url_length,msg.length());
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        }else{
            intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        }
        PendingIntent pendingIntent = PendingIntent.getActivity(this, m_cnt /* Request code */, intent,
                PendingIntent.FLAG_CANCEL_CURRENT);
        Uri defaultSoundUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        String app_name = getString(R.string.app_name);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.tw_icon)
                .setContentTitle(app_name)
                .setContentText(messageBody)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(messageBody))
                .setAutoCancel(true)
                .setColor(Color.parseColor("#fc5d9d"))
                .setSound(defaultSoundUri)
                .setContentIntent(pendingIntent);

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
        boolean Manner_mod = pref.getBoolean("manner_mod",false);
        if(Manner_mod){
            if(Integer.valueOf(formatTime) >= 0 && Integer.valueOf(formatTime) <=6){
            }else{
                notificationManager.notify(m_cnt /* ID of notification */, notificationBuilder.build());
            }
        }else{
            notificationManager.notify(m_cnt /* ID of notification */, notificationBuilder.build());
        }

        SharedPreferences.Editor editor = pref.edit();
        editor.putString("notifi", messageBody.toString()+"\n- " + formatDate.toString()+" -");
        editor.commit();
    }

}