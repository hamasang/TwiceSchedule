package hama.ialpha.kr.twiceschedule2;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Message;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

import android.os.Handler;

import hama.ialpha.kr.twiceschedule2.storage.FunctionStrorage;

public class MainActivity extends Activity {
    EditText msgTextField;

    private final String TAG = "MainActivity";
    private static final String connectURL = "https://twiceapi.ialpha.kr/schedule";
    private static final String Notice = "https://twiceapi.ialpha.kr/notice";
    private boolean app_beta = false;
    private boolean transmission = false;

    private TextView textView;
    private String eventStr, dataStr, sourceStr, noticeStr;
    private String[] Birth;
    private int Birth_count;
    private TextView notice_text;
    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            Bundle bundle = msg.getData();
            String resultStr = bundle.getString("myKey");
            try {
                JSONObject jsonObject = new JSONObject(resultStr);

                boolean success = jsonObject.getBoolean("success");
                String returnMsg = jsonObject.getString("msg");

                if(success){

                    eventStr = jsonObject.getString("event").replaceAll("[\"\"]","").replaceAll("\\[","").replaceAll("\\]","").replace("T","TV").replace("C","Concert").replace("E","ETC").replace("R","Radio").replace("M","Magazine").replaceAll("O","OFF");
                    dataStr = jsonObject.getString("Data").replaceAll("[\"\"]","").replaceAll("\\[","").replaceAll("\\]","");
                    sourceStr = jsonObject.getString("source");
                    String event[] = eventStr.split(",");
                    String data[] = dataStr.split(",");
                    String result[] = new String[event.length+4];
                    textView.setText("");
                    FunctionStrorage.text = "";
                    for(int i = 0; i < event.length; i++){
                           result[i] = event[i] + " - " + data[i];
                           textView.append(result[i]+"\n");
                           FunctionStrorage.text = FunctionStrorage.text+result[i]+"\n";

                    }
                }else{
                    Log.e(TAG, "39Line / handler error");
                    Log.e(TAG, returnMsg);
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    };
    Handler notice_handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            Bundle bundle = msg.getData();
            String resultStr = bundle.getString("myKey");
            try {
                JSONObject jsonObject = new JSONObject(resultStr);

                boolean success = jsonObject.getBoolean("success");
                String returnMsg = jsonObject.getString("msg");
//                app_beta = jsonObject.getBoolean("app_beta");
//                String app_version = jsonObject.getString("app_version");
//                PackageInfo version = getPackageManager().getPackageInfo(getPackageName(), 0);
//                String app_versions = ""+version.versionName;
////                if(!app_beta){
//////                    android.os.Process.killProcess(android.os.Process.myPid());
////                    Toast.makeText(MainActivity.this,"어플리케이션 베타 기간이 지났습니다.",Toast.LENGTH_LONG).show();
////                    finish();
////                }else{
////                    if(!app_version.equals(app_versions)){
////                        Toast.makeText(MainActivity.this,"어플리케이션 업데이트가 필요합니다.",Toast.LENGTH_LONG).show();
////                        finish();
////                    }
////                }
                if(success){

                    noticeStr = jsonObject.getString("notice").replaceAll("[\"\"]","").replaceAll("\\[","").replaceAll("\\]","");
                    String notice[] = noticeStr.split(",");
                    String result[] = new String[notice.length+4];
                    notice_text.setText("");
                    FunctionStrorage.contents = "";
                    for(int i = 0; i < notice.length; i++){
                        result[i] = notice[i];
                        notice_text.append(result[i]+"\n");

                    }
                }else{
                    Log.e(TAG, "39Line / handler error");
                    Log.e(TAG, returnMsg);
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    };


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_activity, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch(id) {
            case R.id.report:
                Intent it = new Intent(Intent.ACTION_SEND);
                String email[] = {"cxa9809@gmail.com"};
                it.putExtra(Intent.EXTRA_EMAIL, email);
                String language = Locale.getDefault().getLanguage();
                if(language.equals("ko")) {
                    it.putExtra(Intent.EXTRA_SUBJECT, "트와이스 스케줄앱 버그 리포트");
                    it.putExtra(Intent.EXTRA_TEXT, "버그 리포트 입니다.\n\n기기명: " + Build.MODEL +"\n안드로이드 버전: " + Build.VERSION.RELEASE + "\n내용: ");
                    it.setType("text/plain");
                    startActivity(Intent.createChooser(it, "이메일 앱을 선택해주세요."));
                }else{
                    it.putExtra(Intent.EXTRA_SUBJECT, "Twice Schedule App Bug Report");
                    it.putExtra(Intent.EXTRA_TEXT, "This is a bug report.\n\nDevice: " + Build.MODEL +"\nAndroid Version: " + Build.VERSION.RELEASE + "\nContent: ");
                    it.setType("text/plain");
                    startActivity(Intent.createChooser(it, "Choose Email Client"));
                }
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = this.getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(this.getResources().getColor(R.color.status));
        }else if(Build.VERSION.SDK_INT == Build.VERSION_CODES.KITKAT){
            //this.setStatusBarColor(MainActivity.this,findViewById(R.id.statusBarBackground),getResources().getColor(R.color.status));
        }
        CheckBox cb = (CheckBox)findViewById(R.id.checkBox);
        notice_text = (TextView)findViewById(R.id.notice_text);
        textView = (TextView)findViewById(R.id.text1);
        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
        final SharedPreferences.Editor editor=pref.edit();
        boolean manner = pref.getBoolean("manner_mod", false);
        if(manner){
            cb.setChecked(true);
        }else{
            cb.setChecked(false);
        }
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    editor.putBoolean("manner_mod",true);
                    editor.apply();
                    editor.commit();
                }else{
                    editor.putBoolean("manner_mod",false);
                    editor.apply();
                    editor.commit();
                }
            }
        });
        getDataFromURL();
        getNotice();

        FirebaseMessaging.getInstance().subscribeToTopic("news");
        FirebaseInstanceId.getInstance().getToken();
        TextView notifi_alarm = (TextView)findViewById(R.id.notifialarm);
        notifi_alarm.setText(pref.getString("notifi", "알림이 없습니다."));
        if(transmission){
            Log.e(TAG,"이미 요청중.");
        }else{
            getDataFromURL();
            Log.e(TAG,"요청완료.");
        }
    }

    //utill
//    public static void setStatusBarColor(MainActivity context , View statusBar,int color){
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//            Window w = context.getWindow();
//            w.setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//            //status bar height
//            //int actionBarHeight = getActionBarHeight();
//            int statusBarHeight = getStatusBarHeight(context);
//            //action bar height
//
//            statusBar.getLayoutParams().height = statusBarHeight;
//            statusBar.setBackgroundColor(color);
//        }else{
//            statusBar.getLayoutParams().height = 0;
//        }
//    }
//    public static int getStatusBarHeight(MainActivity context) {
//        int result = 0;
//        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
//        if (resourceId > 0) {
//            result = context.getResources().getDimensionPixelSize(resourceId);
//        }
//        return result;
//    }
    public void getDataFromURL() {
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                Message msg = handler.obtainMessage();
                Bundle bundle = new Bundle();

                String resultStr = null;

                try{
                    transmission = true;
                    URL url = new URL(connectURL);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                    if(conn != null){
                        conn.setConnectTimeout(10000);
                        conn.setRequestMethod("POST");
                        conn.setDoInput(true);
                        conn.setDoOutput(false);
                        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                        int resCode = conn.getResponseCode();

                        if(resCode == HttpURLConnection.HTTP_OK){
                            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                            resultStr = reader.readLine();
                            reader.close();
                            conn.disconnect();
                        }
                    }else{
                        Log.e(TAG,"101Line / conn null!");
                    }
                }catch (Exception e){
                    transmission = false;
                    resultStr = e.getMessage().toString();
                    textView.setText("");
                    FunctionStrorage.text = "";
                    textView.setText(getString(R.string.networkerror));
                    FunctionStrorage.text = "network Status Check Please.";
                    e.printStackTrace();
                }

                bundle.putString("myKey", resultStr);
                msg.setData(bundle);
                transmission = false;
                handler.sendMessage(msg);
            }// run finish
        };  //runnable finish
        Thread myHttpThread = new Thread(runnable);
        myHttpThread.start();
    }//getDataFromURL finish

    public void getNotice() {
        Runnable runnables = new Runnable() {
            @Override
            public void run() {
                Message msg = notice_handler.obtainMessage();
                Bundle bundle = new Bundle();

                String resultStr = null;

                try{
                    transmission = true;
                    URL url = new URL(Notice);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                    if(conn != null){
                        conn.setConnectTimeout(10000);
                        conn.setRequestMethod("POST");
                        conn.setDoInput(true);
                        conn.setDoOutput(false);
                        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                        int resCode = conn.getResponseCode();

                        if(resCode == HttpURLConnection.HTTP_OK){
                            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                            resultStr = reader.readLine();
                            reader.close();
                            conn.disconnect();
                        }
                    }else{
                        Log.e(TAG,"101Line / conn null!");
                    }
                }catch (Exception e){
                    transmission = false;
                    resultStr = e.getMessage().toString();
                    notice_text.setText("");
                    FunctionStrorage.contents = "";
                    notice_text.setText(getString(R.string.networkerror));
                    FunctionStrorage.contents = "network Status Check Please.";
                    e.printStackTrace();
                }

                bundle.putString("myKey", resultStr);
                msg.setData(bundle);
                transmission = false;
                notice_handler.sendMessage(msg);
            }// run finish
        };  //runnable finish
        Thread myHttpThread = new Thread(runnables);
        myHttpThread.start();
    }//getDataFromURL finish

}
