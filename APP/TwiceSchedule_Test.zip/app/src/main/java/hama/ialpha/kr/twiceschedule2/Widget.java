package hama.ialpha.kr.twiceschedule2;

/**
 * Created by sang on 2016-12-29.
 */

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import hama.ialpha.kr.twiceschedule2.storage.FunctionStrorage;


public class Widget extends AppWidgetProvider {
    private final String TAG = "MainActivity";
    private static final String connectURL = "https://twiceapi.ialpha.kr/schedule";

    private boolean transmission = false;

    private String w_eventStr, w_dataStr, w_sourceStr;
    private String textView = FunctionStrorage.text;
    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            Bundle bundle = msg.getData();
            String resultStr = bundle.getString("myKey");
            try {
                JSONObject jsonObject = new JSONObject(resultStr);

                boolean success = jsonObject.getBoolean("success");
                String returnMsg = jsonObject.getString("msg");

                if (success) {

                    w_eventStr = jsonObject.getString("event").replaceAll("[\"\"]", "").replaceAll("\\[", "").replaceAll("\\]", "").replace("T","TV").replace("C","Concert").replace("E","ETC").replace("R","Radio").replace("M","Magazine").replaceAll("O","OFF");
                    w_dataStr = jsonObject.getString("Data").replaceAll("[\"\"]", "").replaceAll("\\[", "").replaceAll("\\]", "");
                    w_sourceStr = jsonObject.getString("source");
                    String w_event[] = w_eventStr.split(",");
                    String w_data[] = w_dataStr.split(",");
                    String w_result[] = new String[w_event.length + 4];
                    textView = ("");
                    FunctionStrorage.text = "";
                    for (int i = 0; i < w_event.length; i++) {
                        w_result[i] = w_event[i] + " - " + w_data[i];
                        textView = (w_result[i] + "\n");
                        FunctionStrorage.text = FunctionStrorage.text + w_result[i] + "\n";

                    }
                } else {
                    Log.e(TAG, "39Line / handler error");
                    Log.e(TAG, returnMsg);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        final SharedPreferences pref = context.getSharedPreferences("MyPref", 0);
        Boolean enable = pref.getBoolean("eula", false);

        final int count = appWidgetIds.length;
        for (int i = 0; i < count; i++) {
            int widgetId = appWidgetIds[i];
            RemoteViews remoteViews = new RemoteViews(context.getPackageName(),
                    R.layout.simple_widget_layout);
            String number = textView.toString();
            if(enable){
                getDataFromURL();
            }else{
                number = context.getString(R.string.eulacheck);
            }
            if(number.equals("")){
                String language = Locale.getDefault().getLanguage();
                if(language.equals("ko")) {
                    number = "새로고침 해주세요.";
                }else{
                    number = "Refresh Please.";
                }
            }
            remoteViews.setTextViewText(R.id.simple_widget_layout_text, number);
            Date dt = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd, hh:mm:ss a");
            remoteViews.setTextViewText(R.id.times, sdf.format(dt).toString() + "\nSources by Twice Fan's");
            Intent intent = new Intent(context, Widget.class);
            intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, appWidgetIds);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(context,
                    0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
            remoteViews.setOnClickPendingIntent(R.id.simple_widget_layout_activity, pendingIntent);
            appWidgetManager.updateAppWidget(widgetId, remoteViews);
        }

    }

    public void getDataFromURL() {
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                Message msg = handler.obtainMessage();
                Bundle bundle = new Bundle();

                String resultStr = null;

                try {
                    transmission = true;
                    URL url = new URL(connectURL);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                    if (conn != null) {
                        conn.setConnectTimeout(10000);
                        conn.setRequestMethod("POST");
                        conn.setDoInput(true);
                        conn.setDoOutput(false);
                        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                        int resCode = conn.getResponseCode();

                        if (resCode == HttpURLConnection.HTTP_OK) {
                            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                            resultStr = reader.readLine();
                            reader.close();
                            conn.disconnect();
                        }
                    } else {
                        Log.e(TAG, "101Line / conn null!");
                    }
                } catch (Exception e) {
                    transmission = false;
                    resultStr = e.getMessage().toString();
                    textView = ("NetWork Error");
                    e.printStackTrace();
                }

                bundle.putString("myKey", resultStr);
                msg.setData(bundle);
                transmission = false;
                handler.sendMessage(msg);
            }// run finish
        };  //runnable finish
        Thread myHttpThread = new Thread(runnable);
        myHttpThread.start();
    }//getDataFromURL finish
}