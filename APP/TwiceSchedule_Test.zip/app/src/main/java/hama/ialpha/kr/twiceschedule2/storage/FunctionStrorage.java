package hama.ialpha.kr.twiceschedule2.storage;

/**
 * Created by sang on 2016-12-29.
 */

public class FunctionStrorage {
    static public String text = "";
    static public String contents = "";
}
