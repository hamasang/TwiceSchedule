package hama.ialpha.kr.twiceschedule2;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

/**
 * Created by sang on 2016-12-04.
 */

public class StartActivity extends Activity {
    Button agree;
    Button disagree;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start_activity);
        final SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", 0);
        final SharedPreferences.Editor editor=pref.edit();
        agree = (Button)findViewById(R.id.agree);
        disagree = (Button)findViewById(R.id.disagree);
        agree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editor.putBoolean("eula",true);
                editor.apply();
                editor.commit();
                Intent intent = new Intent(StartActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
        disagree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        TextView eula = (TextView)findViewById(R.id.textView3);
        String language = Locale.getDefault().getLanguage();
        if(language.equals("ko")){
            eula.setText("위 앱(Twice Schedule)은 스케줄 알림을 서비스 하기 위해 사용자의 디바이스 토큰(Token)을 수집합니다. 위 앱을 분해 하거나 무단 수정하는 경우 법적인 책임을 물을 수 있으며, 추후 약관 내용이 변경 될 수 있습니다.");
        }else{
            eula.setText("The app (Twice Schedule) collects the user's device token (Token) to serve the schedule. If you break or tamper with the above app, you can take legal responsibility, and the Terms and Conditions may be changed.");
        }
    }
}
